# WhatsApp Chat Export: Sheraz Neighbors
Export date: 9 November 2026 at 2:02 am

---

## 11 September 2026

[2:07 pm] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[2:07 pm] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[2:07 pm] **Sheraz Neighbors:** Hi

[2:11 pm] **Sheraz Neighbors:** [Image]

[2:15 pm] **Sheraz Neighbors:** https://share.google/images/oqZi2Da8Ch5yjjrdV

---

## 12 September 2026

[3:06 pm] **You:** [Voice message]

[3:52 pm] **Sheraz Neighbors:** 03005385459

[10:11 pm] **Sheraz Neighbors:** [Voice message]

[10:11 pm] **You:** [Voice message]

[10:11 pm] **Sheraz Neighbors:**
> _You: Voice message_
Ni sear

[10:11 pm] **Sheraz Neighbors:** Ko Kam ha

[10:12 pm] **Sheraz Neighbors:** Ai ga ha

[10:12 pm] **Sheraz Neighbors:** Bhier ia

[10:12 pm] **You:** [Voice message]

---

## 14 September 2026

[9:26 pm] **You:** Sheraz

[9:26 pm] __Someone turned off disappearing messages__

---

## 8 October 2026

[9:40 pm] **Sheraz Neighbors:** [Image]

[9:54 pm] **You:** [Forwarded] [Image]

[9:59 pm] **Sheraz Neighbors:** [Image]

---

## 10 October 2026

[1:08 pm] **You:** [Sticker]

[1:08 pm] **You:** [Sticker]

[3:50 pm] **Sheraz Neighbors:** hol ap bos ai ha

[7:15 pm] **You:** [Image]

---

## 12 October 2026

[11:48 pm] __[Call]__

---

## 14 October 2026

[12:40 pm] **You:** [Sticker]

[12:40 pm] **You:** [Sticker]

[12:54 pm] **You:** [Sticker]

[1:08 pm] **Sheraz Neighbors:** bol ha man

[1:13 pm] **You:** [Voice message]

[1:24 pm] **Sheraz Neighbors:** aja

[1:24 pm] **You:** ok

---

## 16 October 2026

[2:19 am] **You:** Jag rha hy ya So gya

[1:16 pm] __[Call]__

[7:51 pm] **Sheraz Neighbors:** [Voice message]

[7:52 pm] **You:** [Voice message]

[7:52 pm] **Sheraz Neighbors:** [Voice message]

[8:03 pm] **You:** Boss

[8:48 pm] **Sheraz Neighbors:** abi ni ai

[9:21 pm] **You:** [Voice message]

[11:19 pm] **Sheraz Neighbors:** [Voice message]

---

## 17 October 2026

[5:39 pm] __[Call]__

[10:52 pm] **You:** [Image]

[11:00 pm] **You:** [Image]

---

## 18 October 2026

[10:28 pm] __[Call]__

---

## 20 October 2026

[10:26 am] **Sheraz Neighbors:** bhi ak sagreat to dado

[10:29 am] **You:** Ok

[11:15 am] **Sheraz Neighbors:** hol

[11:15 am] **Sheraz Neighbors:** bhi athe ho sagreat la ai ma pas da do ga

[12:21 pm] **You:** YARA MAIN GAYA HI YA SATH HI SHOP PA

[5:19 pm] **You:** [Image]

[5:20 pm] **Sheraz Neighbors:**
> _You: Image_
ab kea ho jan

[5:22 pm] **You:** [Image]

---

## 21 October 2026

[2:39 pm] __[Call]__

[2:40 pm] __[Call]__

[2:40 pm] __[Call]__

[2:40 pm] __[Call]__

---

## 23 October 2026

[12:24 am] **Sheraz Neighbors:** hol

[12:24 am] **Sheraz Neighbors:** bhi

[12:24 am] **Sheraz Neighbors:** volem Kam kor do please 🙏

[12:25 am] **You:** atna teek hy?

[12:25 am] **Sheraz Neighbors:** ha bhi thak ha

[12:25 am] **Sheraz Neighbors:** thanks

[12:25 am] **Sheraz Neighbors:** [Sticker]

[12:25 am] **Sheraz Neighbors:** [Sticker]

[12:25 am] **Sheraz Neighbors:** [Sticker]

[12:25 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **You:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[12:26 am] **You:** [Sticker]

[12:26 am] **Sheraz Neighbors:** [Sticker]

[1:23 pm] __[Call]__

[1:23 pm] **Sheraz Neighbors:** hol ap ka bos ai ga

[2:52 pm] **You:** [Sticker]

[3:49 pm] **Sheraz Neighbors:**
> _You: Sticker_
ok

[3:49 pm] **Sheraz Neighbors:** [Image]

[3:50 pm] __[Call]__

[3:50 pm] **Sheraz Neighbors:** [Image]

[3:50 pm] **Sheraz Neighbors:** year aja

[3:50 pm] __[Call]__

[3:51 pm] **You:** [Image] 2:52

[3:51 pm] __[Call]__

[3:51 pm] **You:** [Voice message]

[3:51 pm] **You:** [Voice message]

[3:52 pm] **Sheraz Neighbors:** [Voice message]

[3:52 pm] **You:** [Voice message]

[4:53 pm] **Sheraz Neighbors:** [Forwarded] [Video]

[10:38 pm] __[Call]__

[10:38 pm] **Sheraz Neighbors:** hol

[10:49 pm] __[Call]__

[10:50 pm] **Sheraz Neighbors:** bhire aja

[10:53 pm] **You:** ?

---

## 26 October 2026

[12:37 pm] **You:** 🫩

[1:41 pm] **Sheraz Neighbors:** [Sticker]

[6:20 pm] **Sheraz Neighbors:** bhi ma era ho late lan

[6:21 pm] **You:** ????

[6:21 pm] **You:** WHAT

[6:21 pm] **You:** [Sticker]

---

## 27 October 2026

[2:05 pm] **You:** 🍵☕

[2:10 pm] **You:** [Voice message]

[2:10 pm] **You:** [Voice message]

[2:14 pm] **You:** [Sticker]

[2:14 pm] **Sheraz Neighbors:** gg

[2:14 pm] **You:** [Sticker]

[2:14 pm] **Sheraz Neighbors:** g bol kea Bhat ha

[2:15 pm] **Sheraz Neighbors:** bhi

[2:15 pm] **You:** [Voice message]

[2:15 pm] **Sheraz Neighbors:** chi pan ha apn

[2:15 pm] **You:** [Voice message]

[2:17 pm] **Sheraz Neighbors:** abi ap ke chi ai gi ha aijo

[2:17 pm] **Sheraz Neighbors:** aji

[2:18 pm] **Sheraz Neighbors:** ye dhak

[11:53 pm] **You:** Oiey

[11:53 pm] **You:** Ak cigrate 🚬 do

[11:56 pm] __[Call]__

[11:58 pm] **Sheraz Neighbors:** bhi lit band kor do

[11:59 pm] **You:** Cig do akk

[11:59 pm] **You:** [Voice message]

---

## 28 October 2026

[12:00 am] **Sheraz Neighbors:** please 🙏😭

[12:00 am] **Sheraz Neighbors:** suna ha hum na

[12:00 am] **Sheraz Neighbors:** ach ai jao

[12:00 am] **Sheraz Neighbors:** Lea joa

[3:44 pm] **Sheraz Neighbors:** [Voice message]

[3:49 pm] **You:** [Voice message]

[6:58 pm] **You:** [Image]

[10:57 pm] __[Call]__

[11:00 pm] **You:** [Voice message]

[11:01 pm] **You:** [Voice message]

[11:03 pm] __[Call]__

---

## 31 October 2026

[1:15 pm] **You:** azan ho rhi

[2:29 pm] **Sheraz Neighbors:**
> _You: azan ho rhi_
o sorry 😔

[2:58 pm] **You:** 💤😴

[2:58 pm] **Sheraz Neighbors:** ok

[2:58 pm] **You:** 🤐🤫🔇

[2:58 pm] **Sheraz Neighbors:** ok

[8:15 pm] **You:** [Image]

[8:17 pm] **You:** MUHAMMAD SHOAIB AHMED
3740574174125
Brandex@r5s3

---

## 2 November 2026

[2:14 pm] **Sheraz Neighbors:** [Voice message]

[2:15 pm] **Sheraz Neighbors:** helo

[2:15 pm] **Sheraz Neighbors:** o bhi

[2:15 pm] **Sheraz Neighbors:** raple to do

[2:15 pm] **Sheraz Neighbors:** ghalte bol

[2:15 pm] **Sheraz Neighbors:** ne lane ko chaze

[2:15 pm] **Sheraz Neighbors:** ok

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[6:44 pm] **You:** [Sticker]

[7:16 pm] **Sheraz Neighbors:** why

[9:55 pm] __[Call]__

[10:00 pm] **You:** 😡

[10:02 pm] **Sheraz Neighbors:** sorry 😔

[10:02 pm] **Sheraz Neighbors:** ab ne ho ga

[10:02 pm] **You:** ok

---

## 3 November 2026

[8:24 pm] __[Call]__

---

## 4 November 2026

[11:12 pm] **You:** Sheraz 🔥 hy to Day danaa

[11:12 pm] **You:** Lighter

[11:13 pm] **You:** [Sticker]

[11:13 pm] **You:** [Sticker]

---

## 5 November 2026

[1:15 pm] **Sheraz Neighbors:** [Voice message]

[2:46 pm] **Sheraz Neighbors:** o

[2:46 pm] **Sheraz Neighbors:** [Image]

[2:46 pm] **Sheraz Neighbors:** [Image]

[2:46 pm] **Sheraz Neighbors:** aja

[2:47 pm] **Sheraz Neighbors:** area ha

[2:47 pm] __[Call]__

[2:47 pm] **You:** [Voice message]

[2:48 pm] **Sheraz Neighbors:**
> _You: Voice message_
aja

[10:05 pm] **You:** Aiesta kr

[10:05 pm] **You:** 10 ho gaie hain

[10:05 pm] **You:** 🚓🚨 a kar kuttab gain

---

## 6 November 2026

[5:16 pm] **You:** [Sticker]

[6:26 pm] **You:** [Sticker]

[6:26 pm] **You:** [Sticker]

[6:38 pm] **You:** [Voice message]

---

## 7 November 2026

[11:32 am] **You:** Hello

[11:33 am] **Sheraz Neighbors:** g

[11:33 am] **You:** Jaz cash katny hain???

[11:34 am] **Sheraz Neighbors:** 30

[11:35 am] **You:** 😂

[11:35 am] **You:** Cash?

[11:36 am] **You:** Ya ho kya rha hy 🙄😒

[11:40 am] **Sheraz Neighbors:**
> _You: Ya ho kya rha hy 🙄😒_
?

[11:40 am] **You:** Cashhh 💵💲

[11:44 am] **You:** [Sticker]

[11:44 am] **Sheraz Neighbors:** [Voice message]

[11:45 am] **You:** Nhe aca kro

[11:45 am] **You:** Manu goli mar dyoo

[11:45 am] **You:** [Voice message]

[11:46 am] **Sheraz Neighbors:** [Voice message]

[11:47 am] **You:** [Voice message]

[11:48 am] **Sheraz Neighbors:** [Voice message]

[10:28 pm] **Sheraz Neighbors:** https://share.snapchat.com/m/BVwNM47xQwKDna88m4IgzgGhtw3bG30apQtASCpEIXM?src=memories&share_id=U1jPNAPP-YU&locale=en-US

[10:31 pm] **Sheraz Neighbors:** [Image]
